from flask import Flask, jsonify, request, Response
import pathlib
import os

app = Flask(__name__)

EL = ["Fe", "Cr", "Al", "Cu", "Pb", "Sn", "Si", "Na", "K", "B"]
AD = ["Ca", "Zn", "P"]

# ค่า μ และ σ จากตารางกรณีศึกษา (ตัวอย่างข้อมูลจำลอง 699 ตัวอย่าง)
# ไม่ใช่การยืนยันว่าเป็นค่าขีดจำกัดสากลที่ ISO กำหนด
ISO = {
    "Fe": [23.7, 7.7], "Cr": [1.4, 0.5], "Al": [2.6, 1.0],
    "Cu": [4.0, 2.0], "Pb": [2.2, 0.9], "Sn": [0.7, 0.4],
    "Si": [7.5, 1.7], "Na": [2.9, 0.3], "K": [1.0, 0.2],
    "B": [80.0, 3.6]
}

CAUSES = {
    "bearing": "แบริ่งสึก",
    "ring": "แหวน/ปลอกสูบสึก",
    "coolant": "น้ำหล่อเย็นรั่ว",
    "dust": "ฝุ่นเข้า",
    "cu": "Cu ละลายจาก cooler"
}
ACTION = {
    "bearing": "ส่งตรวจสภาพแบริ่งและวางแผนซ่อมตามผลตรวจ",
    "ring": "ตรวจชุดลูกสูบ แหวน และปลอกสูบ",
    "coolant": "ตรวจระบบหล่อเย็นและ oil cooler",
    "dust": "ตรวจท่อไอดีและไส้กรองอากาศ",
    "cu": "ตรวจสอบแนวโน้ม Cu ในรอบถัดไปก่อนสรุปสาเหตุ"
}
RANK = {"Nominal": 0, "Warning": 1, "Severe": 2}

def num(v):
    try:
        return None if v in (None, "") else float(v)
    except (TypeError, ValueError):
        return None

def status(model):
    """ใช้ผลโมเดลที่ผู้ใช้กรอกเอง ไม่ได้เป็นผลจากโมเดลที่เว็บเทรน"""
    if not model:
        return None

    p = {k: (num((model.get("p") or {}).get(k)) or 0) for k in CAUSES}
    rul = num(model.get("rul"))
    anomaly = bool(model.get("anomaly"))
    best, why = "Nominal", []

    def up(level, explanation):
        nonlocal best
        why.append(explanation)
        if RANK[level] > RANK[best]:
            best = level

    for k in ("bearing", "ring"):
        if p[k] >= 0.5:
            if rul is None:
                up("Warning", f"{CAUSES[k]} ≥ 0.5 แต่ยังไม่มี RUL")
            elif rul < 500:
                up("Severe", f"{CAUSES[k]} ≥ 0.5 และ RUL {rul:g} h < 500 h")
            elif rul < 2000:
                up("Warning", f"{CAUSES[k]} ≥ 0.5 และ RUL {rul:g} h < 2,000 h")
            else:
                why.append(f"{CAUSES[k]} ≥ 0.5 แต่ RUL ≥ 2,000 h")

    if p["coolant"] >= 0.5:
        up("Severe", "น้ำหล่อเย็นรั่ว ≥ 0.5")
    if p["dust"] >= 0.5:
        up("Warning", "ฝุ่นเข้า ≥ 0.5")
    if p["cu"] >= 0.5:
        why.append("Cu ละลายจาก cooler: ไม่ยกระดับสถานะด้วยกติกานี้")

    top = max(CAUSES, key=lambda k: p[k]) if any(p.values()) else None
    if anomaly and not any(p[k] >= 0.5 for k in CAUSES):
        up("Warning", "Isolation Forest แจ้ง anomaly แต่ยังไม่เข้าเกณฑ์สาเหตุ")

    return {
        "level": best,
        "why": why or ["ไม่เข้าเงื่อนไขยกระดับสถานะ"],
        "next_h": 50 if best == "Severe" else 250,
        "action": ACTION.get(top) if top and p[top] >= 0.5 else None,
        "top": CAUSES.get(top) if top else None
    }

@app.post("/api/calc")
def calc():
    d = request.get_json(force=True)
    iso = d.get("iso", ISO)
    base = d.get("base", {})
    samples = d.get("samples", [])
    out = []

    for i, s in enumerate(samples):
        age = num(s.get("age"))
        gap = num(s.get("gap")) or 250.0
        r = {
            "i": i, "err": None, "m": {}, "delta": {}, "rate": {},
            "z": {}, "trend": {}, "level": {}, "ratio": {},
            "add": [], "topup_rate": None, "flag": None,
            "status": status(s.get("model"))
        }

        if not age or age <= 0:
            r["err"] = "อายุน้ำมันต้องมากกว่า 0 h"
            out.append(r)
            continue

        for el in EL:
            m = num((s.get("m") or {}).get(el))
            b = num(base.get(el)) or 0.0
            r["m"][el] = m
            if m is None:
                continue

            mu, sd = float(iso[el][0]), float(iso[el][1])
            r["delta"][el] = m - b
            r["rate"][el] = (m - b) / age * 100
            r["z"][el] = (m - mu) / sd if sd else None
            r["level"][el] = (
                "Severe" if m > mu + 2 * sd else
                "Warning" if m > mu + sd else "ปกติ"
            )

        prior = sorted(
            [
                x for x in samples
                if x.get("car") == s.get("car")
                and (num(x.get("hrs")) or 0) < (num(s.get("hrs")) or 0)
                and num(x.get("age"))
            ],
            key=lambda x: -(num(x.get("hrs")) or 0)
        )[:2]

        if len(prior) == 2:
            for el in r["rate"]:
                pr = [
                    (num(x["m"].get(el)) - (num(base.get(el)) or 0))
                    / num(x["age"]) * 100
                    for x in prior if num(x["m"].get(el)) is not None
                ]
                if len(pr) == 2:
                    r["trend"][el] = r["rate"][el] - sum(pr) / 2

        D = r["delta"]
        q = lambda a, b: D[a] / D[b] if a in D and b in D and D[b] > 0 else None
        r["ratio"] = {
            "Al/Si": q("Al", "Si"),
            "(Pb+Sn)/Cu": (
                (D["Pb"] + D["Sn"]) / D["Cu"]
                if all(k in D for k in ("Pb", "Sn", "Cu")) and D["Cu"] > 0
                else None
            ),
            "Cr/Fe": q("Cr", "Fe"),
            "K/Na": q("K", "Na")
        }

        off = avail = 0
        for el in AD:
            m = num((s.get("m") or {}).get(el))
            b = num(base.get(el))
            pct = (m - b) / b * 100 if m is not None and b else None
            if pct is not None:
                avail += 1
                off += abs(pct) > 10
            r["add"].append({"el": el, "m": m, "base": b, "pct": pct})
        r["flag"] = True if off >= 2 else (False if avail == 3 else None)

        top = num(s.get("topup"))
        r["topup_rate"] = top / gap * 100 if top is not None and gap > 0 else None
        out.append(r)

    return jsonify(out)

PAGE = (pathlib.Path(__file__).parent / "page.html").read_text(encoding="utf-8")

@app.get("/")
def index():
    return Response(PAGE, mimetype="text/html")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)), debug=False)
