# Oil Analysis PdM (Flask)

## Deploy on Render using GitHub
1. Upload this folder's files to a GitHub repository.
2. In Render, choose New + -> Web Service.
3. Connect the GitHub repository.
4. Use:
   - Runtime: Python
   - Build command: `pip install -r requirements.txt`
   - Start command: `gunicorn app:app`
5. Deploy. Render will provide a public URL.

## Run locally
```bash
pip install -r requirements.txt
python app.py
```
Open http://127.0.0.1:5000

The example μ and σ values are from the case-study table (simulated data), not universal ISO limits. ML models are not trained; manually entered model outputs are only used to apply the displayed status rules.
